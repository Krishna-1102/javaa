package com.example.studentmanagement;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Student {

    @Id
    private Long studentId;

    private String studentName;

    @Email
    private String email;

    private String courseName;

    @Min(0)
    @Max(100)
    private int programmingScore;

    @Min(0)
    @Max(100)
    private int mathematicsScore;

    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> technicalSkills = new ArrayList<>();

    public Student() {}

    public Student(Long studentId, String studentName,
                   String email, String courseName,
                   int programmingScore, int mathematicsScore,
                   List<String> technicalSkills) {

        this.studentId = studentId;
        this.studentName = studentName;
        this.email = email;
        this.courseName = courseName;
        this.programmingScore = programmingScore;
        this.mathematicsScore = mathematicsScore;
        this.technicalSkills = technicalSkills;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getProgrammingScore() {
        return programmingScore;
    }

    public void setProgrammingScore(int programmingScore) {
        this.programmingScore = programmingScore;
    }

    public int getMathematicsScore() {
        return mathematicsScore;
    }

    public void setMathematicsScore(int mathematicsScore) {
        this.mathematicsScore = mathematicsScore;
    }

    public List<String> getTechnicalSkills() {
        return technicalSkills;
    }

    public void setTechnicalSkills(List<String> technicalSkills) {
        this.technicalSkills = technicalSkills;
    }

    public double getAverageScore() {
        return (programmingScore + mathematicsScore) / 2.0;
    }

    public String getPerformanceCategory() {
        double avg = getAverageScore();

        if (avg >= 85) return "Excellent";
        if (avg >= 70) return "Good";
        if (avg >= 50) return "Satisfactory";

        return "Needs Improvement";
    }

    public String getStrongerSubject() {
        if (programmingScore > mathematicsScore)
            return "Programming";

        if (mathematicsScore > programmingScore)
            return "Mathematics";

        return "Equal";
    }

    @Override
    public String toString() {
        return studentId + " - " + studentName;
    }
}