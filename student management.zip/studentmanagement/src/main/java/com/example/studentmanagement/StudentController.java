package com.example.studentmanagement;

import java.util.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentRepository repo;

    public StudentController(StudentRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public ResponseEntity<?> add(@Valid @RequestBody Student s) {
        if (s.getStudentId() == null)
            return ResponseEntity.badRequest().body("Student ID required");

        if (repo.existsById(s.getStudentId()))
            return ResponseEntity.status(409).body("Duplicate Student ID");

        return ResponseEntity.status(201).body(repo.save(s));
    }

    @GetMapping
    public List<Student> all() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> byId(@PathVariable Long id) {
        return repo.findById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/email")
    public List<Student> byEmail(@RequestParam String value) {
        return repo.findByEmail(value);
    }

    @GetMapping("/course")
    public List<Student> byCourse(@RequestParam String value) {
        return repo.findByCourseNameIgnoreCase(value);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(
            @PathVariable Long id,
            @Valid @RequestBody Student data) {

        Optional<Student> found = repo.findById(id);

        if (found.isEmpty())
            return ResponseEntity.notFound().build();

        Student s = found.get();
        s.setProgrammingScore(data.getProgrammingScore());
        s.setMathematicsScore(data.getMathematicsScore());
        s.setTechnicalSkills(data.getTechnicalSkills());

        return ResponseEntity.ok(repo.save(s));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (!repo.existsById(id))
            return ResponseEntity.notFound().build();

        repo.deleteById(id);
        return ResponseEntity.ok("Student deleted");
    }

    @GetMapping("/merit")
    public List<Student> merit() {
        List<Student> students = repo.findAll();

        students.sort(
            Comparator.comparingDouble(Student::getAverageScore)
                      .reversed()
        );

        return students;
    }

    @GetMapping("/improvement")
    public List<Student> improvement() {
        return repo.findAll().stream()
                .filter(s -> s.getProgrammingScore() < 50
                          && s.getMathematicsScore() >= 75)
                .toList();
    }

    @GetMapping("/common-skills")
    public Map<String, List<Long>> commonSkills() {
        Map<String, List<Long>> skillMap = new HashMap<>();

        for (Student s : repo.findAll()) {
            Set<String> uniqueSkills =
                    new HashSet<>(s.getTechnicalSkills());

            for (String skill : uniqueSkills) {
                skillMap.computeIfAbsent(
                    skill, k -> new ArrayList<>()
                ).add(s.getStudentId());
            }
        }

        skillMap.entrySet().removeIf(
            entry -> entry.getValue().size() < 2
        );

        return skillMap;
    }
}